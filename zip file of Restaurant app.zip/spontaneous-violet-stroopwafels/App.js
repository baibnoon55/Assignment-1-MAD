                

import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TextInput,
  Image,
  TouchableOpacity,
  SafeAreaView,
  FlatList,
  Modal,
  Alert,
  Dimensions,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';

const { width } = Dimensions.get('window');

// ============ BLACK + BROWN THEME ============
const COLORS = {
  background: '#000000',
  primary: '#8B4513',
  secondary: '#A0522D',
  text: '#8B4513',
  textLight: '#CD853F',
  card: '#1A1A1A',
  border: '#8B4513',
  white: '#FFFFFF',
  black: '#000000',
  gray: '#666666',
  success: '#4CAF50',
};

// ============ IMAGES ============
const IMAGES = {
  chickenKarahi: 'https://images.unsplash.com/photo-1606491956689-2ea866880c84?w=400',
  chickenBiryani: 'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?w=400',
  muttonHandi: 'https://images.unsplash.com/photo-1585937421612-70a008356fbe?w=400',
  daalMakhni: 'https://images.unsplash.com/photo-1626131349907-68e0f49d50e9?w=400',
  zinger: 'https://images.unsplash.com/photo-1571091718767-18b5b1457add?w=400',
  chai: 'https://images.unsplash.com/photo-1544787219-7f47ccb76574?w=400',
  
  // Quick Options Images
  teas: 'https://images.unsplash.com/photo-1544787219-7f47ccb76574?w=400',
  burgers: 'https://images.unsplash.com/photo-1571091718767-18b5b1457add?w=400',
  pizzas: 'https://images.unsplash.com/photo-1574071318508-1cdbab80d002?w=400',
  scan: 'https://images.unsplash.com/photo-1586281380117-5a60ae2050cc?w=400',
  reviews: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=400',
  offers: 'https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?w=400',
};

// ============ LOGIN SCREEN ============
const LoginScreen = ({ onLogin }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  return (
    <View style={loginStyles.container}>
      <View style={loginStyles.overlay}>
        <View style={loginStyles.header}>
          <Text style={loginStyles.logo}>🍽️</Text>
          <Text style={loginStyles.title}>NOON</Text>
          <Text style={loginStyles.subtitle}>RESTAURANT</Text>
        </View>

        <View style={loginStyles.form}>
          <TextInput
            style={loginStyles.input}
            placeholder="Email"
            placeholderTextColor={COLORS.gray}
            value={email}
            onChangeText={setEmail}
          />
          <TextInput
            style={loginStyles.input}
            placeholder="Password"
            placeholderTextColor={COLORS.gray}
            value={password}
            onChangeText={setPassword}
            secureTextEntry
          />
          <TouchableOpacity style={loginStyles.loginButton} onPress={onLogin}>
            <Text style={loginStyles.loginButtonText}>Login</Text>
          </TouchableOpacity>
          <TouchableOpacity style={loginStyles.guestButton} onPress={onLogin}>
            <Text style={loginStyles.guestButtonText}>Continue as Guest</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
};

const loginStyles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.8)',
    padding: 20,
    justifyContent: 'center',
  },
  header: {
    alignItems: 'center',
    marginBottom: 40,
  },
  logo: {
    fontSize: 80,
    marginBottom: 10,
  },
  title: {
    fontSize: 40,
    fontWeight: 'bold',
    color: COLORS.primary,
    letterSpacing: 5,
  },
  subtitle: {
    fontSize: 18,
    color: COLORS.textLight,
    letterSpacing: 3,
  },
  form: {
    backgroundColor: COLORS.card,
    borderRadius: 30,
    padding: 20,
    borderWidth: 1,
    borderColor: COLORS.primary,
  },
  input: {
    backgroundColor: COLORS.black,
    borderRadius: 15,
    padding: 15,
    marginBottom: 15,
    fontSize: 16,
    color: COLORS.text,
    borderWidth: 1,
    borderColor: COLORS.primary,
  },
  loginButton: {
    backgroundColor: COLORS.primary,
    borderRadius: 15,
    padding: 15,
    alignItems: 'center',
    marginBottom: 10,
  },
  loginButtonText: {
    color: COLORS.black,
    fontSize: 16,
    fontWeight: '600',
  },
  guestButton: {
    backgroundColor: 'transparent',
    borderRadius: 15,
    padding: 15,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: COLORS.primary,
  },
  guestButtonText: {
    color: COLORS.primary,
    fontSize: 16,
    fontWeight: '600',
  },
});

// ============ CART SCREEN ============
const CartScreen = ({ visible, items, onClose, onCheckout }) => {
  const total = items.reduce((sum, item) => {
    return sum + parseInt(item.price.replace(',', ''));
  }, 0);

  const deliveryCharge = 150;
  const tax = Math.round(total * 0.05);
  const grandTotal = total + deliveryCharge + tax;

  return (
    <Modal visible={visible} transparent animationType="slide">
      <View style={cartStyles.modalOverlay}>
        <View style={cartStyles.modalContent}>
          <View style={cartStyles.header}>
            <Text style={cartStyles.title}>Your Cart</Text>
            <TouchableOpacity onPress={onClose}>
              <Ionicons name="close" size={24} color={COLORS.primary} />
            </TouchableOpacity>
          </View>

          <FlatList
            data={items}
            keyExtractor={(item) => item.id.toString()}
            contentContainerStyle={cartStyles.list}
            renderItem={({ item }) => (
              <View style={cartStyles.cartItem}>
                <Image source={{ uri: item.image }} style={cartStyles.itemImage} />
                <View style={cartStyles.itemInfo}>
                  <Text style={cartStyles.itemName}>{item.name}</Text>
                  <Text style={cartStyles.itemPrice}>Rs. {item.price}</Text>
                </View>
              </View>
            )}
          />

          <View style={cartStyles.summary}>
            <Text style={cartStyles.summaryTitle}>Order Summary</Text>
            
            <View style={cartStyles.summaryRow}>
              <Text style={cartStyles.summaryLabel}>Subtotal:</Text>
              <Text style={cartStyles.summaryValue}>Rs. {total.toLocaleString()}</Text>
            </View>
            
            <View style={cartStyles.summaryRow}>
              <Text style={cartStyles.summaryLabel}>Delivery Charge:</Text>
              <Text style={cartStyles.summaryValue}>Rs. {deliveryCharge}</Text>
            </View>
            
            <View style={cartStyles.summaryRow}>
              <Text style={cartStyles.summaryLabel}>Tax (5%):</Text>
              <Text style={cartStyles.summaryValue}>Rs. {tax}</Text>
            </View>
            
            <View style={[cartStyles.summaryRow, cartStyles.totalRow]}>
              <Text style={cartStyles.totalLabel}>Total:</Text>
              <Text style={cartStyles.totalValue}>Rs. {grandTotal.toLocaleString()}</Text>
            </View>
          </View>

          <TouchableOpacity style={cartStyles.checkoutButton} onPress={onCheckout}>
            <Text style={cartStyles.checkoutButtonText}>Proceed to Payment</Text>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );
};

const cartStyles = StyleSheet.create({
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.9)',
    justifyContent: 'flex-end',
  },
  modalContent: {
    backgroundColor: COLORS.card,
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
    padding: 20,
    maxHeight: '90%',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
    paddingBottom: 10,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.primary,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: COLORS.primary,
  },
  list: {
    paddingBottom: 20,
  },
  cartItem: {
    flexDirection: 'row',
    backgroundColor: COLORS.black,
    borderRadius: 12,
    padding: 10,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  itemImage: {
    width: 50,
    height: 50,
    borderRadius: 25,
    marginRight: 10,
  },
  itemInfo: {
    flex: 1,
    justifyContent: 'center',
  },
  itemName: {
    fontSize: 14,
    fontWeight: '600',
    color: COLORS.primary,
  },
  itemPrice: {
    fontSize: 14,
    color: COLORS.textLight,
    marginTop: 4,
  },
  summary: {
    backgroundColor: COLORS.black,
    borderRadius: 15,
    padding: 15,
    marginVertical: 15,
    borderWidth: 1,
    borderColor: COLORS.primary,
  },
  summaryTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: COLORS.primary,
    marginBottom: 15,
  },
  summaryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  summaryLabel: {
    fontSize: 14,
    color: COLORS.textLight,
  },
  summaryValue: {
    fontSize: 14,
    color: COLORS.text,
  },
  totalRow: {
    marginTop: 10,
    paddingTop: 10,
    borderTopWidth: 1,
    borderTopColor: COLORS.border,
  },
  totalLabel: {
    fontSize: 16,
    fontWeight: 'bold',
    color: COLORS.primary,
  },
  totalValue: {
    fontSize: 18,
    fontWeight: 'bold',
    color: COLORS.primary,
  },
  checkoutButton: {
    backgroundColor: COLORS.primary,
    padding: 15,
    borderRadius: 15,
    alignItems: 'center',
  },
  checkoutButtonText: {
    color: COLORS.black,
    fontSize: 16,
    fontWeight: '600',
  },
});

// ============ PAYMENT SCREEN ============
const PaymentScreen = ({ visible, totalAmount, onClose, onPaymentComplete }) => {
  const [selectedMethod, setSelectedMethod] = useState(null);
  const [showOnlineOptions, setShowOnlineOptions] = useState(false);

  const paymentMethods = [
    { id: 1, name: 'Cash on Delivery', icon: '💵', type: 'cash' },
    { id: 2, name: 'Online Payment', icon: '🌐', type: 'online' },
  ];

  const onlineMethods = [
    { id: 3, name: 'JazzCash', icon: '📱', account: '0300-1234567' },
    { id: 4, name: 'Easypaisa', icon: '📲', account: '0300-7654321' },
    { id: 5, name: 'Credit Card', icon: '💳', account: '**** **** **** 1234' },
  ];

  const handlePayment = () => {
    if (!selectedMethod) {
      Alert.alert('Error', 'Please select a payment method');
      return;
    }
    onPaymentComplete();
  };

  return (
    <Modal visible={visible} transparent animationType="slide">
      <View style={paymentStyles.modalOverlay}>
        <View style={paymentStyles.modalContent}>
          <View style={paymentStyles.header}>
            <Text style={paymentStyles.title}>Payment</Text>
            <TouchableOpacity onPress={onClose}>
              <Ionicons name="close" size={24} color={COLORS.primary} />
            </TouchableOpacity>
          </View>

          <Text style={paymentStyles.totalAmount}>Total: Rs. {totalAmount}</Text>

          {paymentMethods.map((method) => (
            <TouchableOpacity
              key={method.id}
              style={[
                paymentStyles.methodCard,
                selectedMethod === method.id && paymentStyles.methodSelected,
              ]}
              onPress={() => {
                setSelectedMethod(method.id);
                setShowOnlineOptions(method.type === 'online');
              }}
            >
              <Text style={paymentStyles.methodIcon}>{method.icon}</Text>
              <Text style={paymentStyles.methodName}>{method.name}</Text>
              {selectedMethod === method.id && (
                <Ionicons name="checkmark-circle" size={24} color={COLORS.primary} />
              )}
            </TouchableOpacity>
          ))}

          {showOnlineOptions && (
            <View style={paymentStyles.onlineContainer}>
              <Text style={paymentStyles.onlineTitle}>Select Online Method</Text>
              {onlineMethods.map((method) => (
                <TouchableOpacity
                  key={method.id}
                  style={paymentStyles.onlineCard}
                  onPress={() => setSelectedMethod(method.id)}
                >
                  <Text style={paymentStyles.onlineIcon}>{method.icon}</Text>
                  <View style={paymentStyles.onlineInfo}>
                    <Text style={paymentStyles.onlineName}>{method.name}</Text>
                    <Text style={paymentStyles.onlineAccount}>{method.account}</Text>
                  </View>
                  {selectedMethod === method.id && (
                    <Ionicons name="checkmark-circle" size={24} color={COLORS.primary} />
                  )}
                </TouchableOpacity>
              ))}
            </View>
          )}

          <TouchableOpacity style={paymentStyles.payButton} onPress={handlePayment}>
            <Text style={paymentStyles.payButtonText}>Pay Now</Text>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );
};

const paymentStyles = StyleSheet.create({
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.9)',
    justifyContent: 'flex-end',
  },
  modalContent: {
    backgroundColor: COLORS.card,
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
    padding: 20,
    maxHeight: '80%',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 15,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: COLORS.primary,
  },
  totalAmount: {
    fontSize: 20,
    fontWeight: 'bold',
    color: COLORS.primary,
    textAlign: 'center',
    marginBottom: 20,
    padding: 15,
    backgroundColor: COLORS.black,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: COLORS.primary,
  },
  methodCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.black,
    borderRadius: 12,
    padding: 15,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  methodSelected: {
    borderColor: COLORS.primary,
    borderWidth: 2,
  },
  methodIcon: {
    fontSize: 24,
    marginRight: 15,
  },
  methodName: {
    flex: 1,
    fontSize: 16,
    color: COLORS.text,
  },
  onlineContainer: {
    marginTop: 15,
    paddingTop: 15,
    borderTopWidth: 1,
    borderTopColor: COLORS.border,
  },
  onlineTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: COLORS.primary,
    marginBottom: 10,
  },
  onlineCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.black,
    borderRadius: 10,
    padding: 12,
    marginBottom: 8,
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  onlineIcon: {
    fontSize: 20,
    marginRight: 12,
  },
  onlineInfo: {
    flex: 1,
  },
  onlineName: {
    fontSize: 14,
    color: COLORS.primary,
    fontWeight: '600',
  },
  onlineAccount: {
    fontSize: 12,
    color: COLORS.textLight,
    marginTop: 2,
  },
  payButton: {
    backgroundColor: COLORS.primary,
    padding: 15,
    borderRadius: 15,
    alignItems: 'center',
    marginTop: 20,
  },
  payButtonText: {
    color: COLORS.black,
    fontSize: 16,
    fontWeight: '600',
  },
});

// ============ THANK YOU SCREEN ============
const ThankYouScreen = ({ visible, onClose }) => {
  return (
    <Modal visible={visible} transparent animationType="fade">
      <View style={thankyouStyles.modalOverlay}>
        <View style={thankyouStyles.modalContent}>
          <Text style={thankyouStyles.emoji}>🎉</Text>
          <Text style={thankyouStyles.title}>Thank You!</Text>
          <Text style={thankyouStyles.subtitle}>Your order has been placed</Text>
          
          <View style={thankyouStyles.divider} />
          
          <Text style={thankyouStyles.message}>We appreciate your business</Text>
          <Text style={thankyouStyles.urduMessage}>آپ کا شکریہ</Text>
          
          <TouchableOpacity style={thankyouStyles.button} onPress={onClose}>
            <Text style={thankyouStyles.buttonText}>Continue Shopping</Text>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );
};

const thankyouStyles = StyleSheet.create({
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.9)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    backgroundColor: COLORS.card,
    borderRadius: 30,
    padding: 30,
    width: '80%',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: COLORS.primary,
  },
  emoji: {
    fontSize: 80,
    marginBottom: 20,
  },
  title: {
    fontSize: 32,
    fontWeight: 'bold',
    color: COLORS.primary,
    marginBottom: 10,
  },
  subtitle: {
    fontSize: 18,
    color: COLORS.textLight,
    marginBottom: 20,
  },
  divider: {
    width: 100,
    height: 2,
    backgroundColor: COLORS.primary,
    marginVertical: 20,
  },
  message: {
    fontSize: 16,
    color: COLORS.text,
    marginBottom: 5,
  },
  urduMessage: {
    fontSize: 20,
    color: COLORS.primary,
    marginBottom: 30,
    writingDirection: 'rtl',
  },
  button: {
    backgroundColor: COLORS.primary,
    paddingHorizontal: 30,
    paddingVertical: 12,
    borderRadius: 25,
  },
  buttonText: {
    color: COLORS.black,
    fontSize: 16,
    fontWeight: '600',
  },
});

// ============ CATEGORY SCREEN ============
const CategoryScreen = ({ navigation, title, items, onItemSelect, selectedItems }) => {
  return (
    <View style={categoryStyles.container}>
      <SafeAreaView style={categoryStyles.safeArea}>
        <View style={categoryStyles.header}>
          <TouchableOpacity onPress={() => navigation.goBack()}>
            <Ionicons name="arrow-back" size={24} color={COLORS.primary} />
          </TouchableOpacity>
          <Text style={categoryStyles.headerTitle}>{title}</Text>
          <View style={{ width: 24 }} />
        </View>

        <FlatList
          data={items}
          keyExtractor={(item) => item.id.toString()}
          contentContainerStyle={categoryStyles.list}
          renderItem={({ item }) => {
            const isSelected = selectedItems.find(i => i.id === item.id);
            return (
              <TouchableOpacity 
                style={[categoryStyles.itemCard, isSelected && categoryStyles.itemCardSelected]}
                onPress={() => onItemSelect(item)}
              >
                <Image source={{ uri: item.image }} style={categoryStyles.itemImage} />
                <View style={categoryStyles.itemInfo}>
                  <Text style={categoryStyles.itemName}>{item.name}</Text>
                  <Text style={categoryStyles.itemDesc}>{item.description}</Text>
                  <View style={categoryStyles.itemDetails}>
                    <Text style={categoryStyles.itemPrice}>Rs. {item.price}</Text>
                    <Text style={categoryStyles.itemWeight}>/{item.weight}</Text>
                  </View>
                </View>
                <View style={[categoryStyles.selectCircle, isSelected && categoryStyles.selectCircleSelected]}>
                  {isSelected && <Ionicons name="checkmark" size={20} color={COLORS.black} />}
                </View>
              </TouchableOpacity>
            );
          }}
        />
      </SafeAreaView>
    </View>
  );
};

const categoryStyles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  safeArea: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: 10,
    paddingBottom: 10,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.primary,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: COLORS.primary,
  },
  list: {
    padding: 15,
  },
  itemCard: {
    flexDirection: 'row',
    backgroundColor: COLORS.card,
    borderRadius: 15,
    padding: 12,
    marginBottom: 10,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  itemCardSelected: {
    borderColor: COLORS.primary,
    borderWidth: 2,
  },
  itemImage: {
    width: 70,
    height: 70,
    borderRadius: 35,
    marginRight: 12,
  },
  itemInfo: {
    flex: 1,
  },
  itemName: {
    fontSize: 16,
    fontWeight: '600',
    color: COLORS.primary,
    marginBottom: 4,
  },
  itemDesc: {
    fontSize: 12,
    color: COLORS.textLight,
    marginBottom: 4,
  },
  itemDetails: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  itemPrice: {
    fontSize: 16,
    fontWeight: 'bold',
    color: COLORS.primary,
  },
  itemWeight: {
    fontSize: 12,
    color: COLORS.textLight,
    marginLeft: 4,
  },
  selectCircle: {
    width: 28,
    height: 28,
    borderRadius: 14,
    borderWidth: 2,
    borderColor: COLORS.primary,
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 10,
  },
  selectCircleSelected: {
    backgroundColor: COLORS.primary,
  },
});

// ============ HOME SCREEN WITH QUICK OPTIONS ============
const HomeScreen = ({ navigation, cartItems, setCartItems }) => {
  const [showReservation, setShowReservation] = useState(false);
  const [guests, setGuests] = useState('2');
  const [showCart, setShowCart] = useState(false);
  const [showPayment, setShowPayment] = useState(false);
  const [showThankYou, setShowThankYou] = useState(false);
  const [selectedOption, setSelectedOption] = useState(null);
  const [showOptionDetail, setShowOptionDetail] = useState(false);

  const categories = [
    {
      id: 1,
      name: 'DESI FOOD',
      icon: '🍛',
      screen: 'Desi',
      image: IMAGES.chickenKarahi,
    },
    {
      id: 2,
      name: 'FAST FOOD',
      icon: '🍔',
      screen: 'FastFood',
      image: IMAGES.zinger,
    },
    {
      id: 3,
      name: 'SWEETS',
      icon: '🍮',
      screen: 'Sweets',
      image: IMAGES.daalMakhni,
    },
    {
      id: 4,
      name: 'DRINKS & TEA',
      icon: '☕',
      screen: 'Drinks',
      image: IMAGES.chai,
    },
  ];

  // Quick Options Data
  const quickOptions = [
    { id: 1, name: 'Brewed Teas', icon: '🫖', image: IMAGES.teas, description: 'Fresh brewed teas & traditional chai' },
    { id: 2, name: 'Burgers', icon: '🍔', image: IMAGES.burgers, description: 'Juicy burgers with crispy fries' },
    { id: 3, name: 'Pizzas', icon: '🍕', image: IMAGES.pizzas, description: 'Wood fired pizzas with fresh toppings' },
    { id: 4, name: 'Scan Table', icon: '📱', image: IMAGES.scan, description: 'Scan QR code to view menu & order' },
    { id: 5, name: 'Reviews', icon: '⭐', image: IMAGES.reviews, description: 'See what our customers say' },
    { id: 6, name: 'Offers', icon: '🏷️', image: IMAGES.offers, description: 'Special deals & discounts' },
  ];

  const total = cartItems.reduce((sum, item) => {
    return sum + parseInt(item.price.replace(',', ''));
  }, 0);

  const deliveryCharge = 150;
  const tax = Math.round(total * 0.05);
  const grandTotal = total + deliveryCharge + tax;

  const handleCheckout = () => {
    setShowCart(false);
    setShowPayment(true);
  };

  const handlePaymentComplete = () => {
    setShowPayment(false);
    setShowThankYou(true);
  };

  const handleThankYouClose = () => {
    setShowThankYou(false);
    setCartItems([]);
  };

  const handleOptionPress = (option) => {
    setSelectedOption(option);
    setShowOptionDetail(true);
  };

  const renderOptionDetail = () => {
    if (!selectedOption) return null;

    return (
      <Modal visible={showOptionDetail} transparent animationType="slide">
        <View style={homeStyles.modalOverlay}>
          <View style={homeStyles.optionDetailContent}>
            <View style={homeStyles.optionDetailHeader}>
              <TouchableOpacity onPress={() => setShowOptionDetail(false)}>
                <Ionicons name="close" size={24} color={COLORS.primary} />
              </TouchableOpacity>
              <Text style={homeStyles.optionDetailTitle}>{selectedOption.name}</Text>
              <View style={{ width: 24 }} />
            </View>

            <Image source={{ uri: selectedOption.image }} style={homeStyles.optionDetailImage} />
            
            <Text style={homeStyles.optionDetailDesc}>{selectedOption.description}</Text>
            
            <View style={homeStyles.optionDetailItems}>
              <Text style={homeStyles.optionDetailItemsTitle}>Popular Items:</Text>
              {selectedOption.name === 'Brewed Teas' && (
                <>
                  <Text style={homeStyles.optionDetailItem}>• Karak Chai - Rs. 199</Text>
                  <Text style={homeStyles.optionDetailItem}>• Kashmiri Chai - Rs. 299</Text>
                  <Text style={homeStyles.optionDetailItem}>• Green Tea - Rs. 199</Text>
                  <Text style={homeStyles.optionDetailItem}>• Coffee - Rs. 349</Text>
                </>
              )}
              {selectedOption.name === 'Burgers' && (
                <>
                  <Text style={homeStyles.optionDetailItem}>• Zinger Burger - Rs. 899</Text>
                  <Text style={homeStyles.optionDetailItem}>• Beef Burger - Rs. 999</Text>
                  <Text style={homeStyles.optionDetailItem}>• Chicken Shawarma - Rs. 599</Text>
                  <Text style={homeStyles.optionDetailItem}>• French Fries - Rs. 399</Text>
                </>
              )}
              {selectedOption.name === 'Pizzas' && (
                <>
                  <Text style={homeStyles.optionDetailItem}>• Chicken Fajita - Rs. 1299</Text>
                  <Text style={homeStyles.optionDetailItem}>• Margherita - Rs. 999</Text>
                  <Text style={homeStyles.optionDetailItem}>• BBQ Chicken - Rs. 1499</Text>
                  <Text style={homeStyles.optionDetailItem}>• Veggie Supreme - Rs. 1099</Text>
                </>
              )}
              {selectedOption.name === 'Scan Table' && (
                <>
                  <Text style={homeStyles.optionDetailItem}>• Scan QR code on your table</Text>
                  <Text style={homeStyles.optionDetailItem}>• View digital menu instantly</Text>
                  <Text style={homeStyles.optionDetailItem}>• Order directly from table</Text>
                  <Text style={homeStyles.optionDetailItem}>• Pay contactless</Text>
                </>
              )}
              {selectedOption.name === 'Reviews' && (
                <>
                  <Text style={homeStyles.optionDetailItem}>• ⭐⭐⭐⭐⭐ - 4.8 (2.5k reviews)</Text>
                  <Text style={homeStyles.optionDetailItem}>• "Best food in town!" - Ahmed</Text>
                  <Text style={homeStyles.optionDetailItem}>• "Amazing service" - Fatima</Text>
                  <Text style={homeStyles.optionDetailItem}>• "Great ambiance" - Usman</Text>
                </>
              )}
              {selectedOption.name === 'Offers' && (
                <>
                  <Text style={homeStyles.optionDetailItem}>• 20% off on first order</Text>
                  <Text style={homeStyles.optionDetailItem}>• Buy 1 Get 1 on Burgers</Text>
                  <Text style={homeStyles.optionDetailItem}>• Free delivery over Rs. 1000</Text>
                  <Text style={homeStyles.optionDetailItem}>• Happy Hours 3-6 PM</Text>
                </>
              )}
            </View>

            <TouchableOpacity 
              style={homeStyles.optionDetailButton}
              onPress={() => setShowOptionDetail(false)}
            >
              <Text style={homeStyles.optionDetailButtonText}>Close</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    );
  };

  return (
    <View style={homeStyles.container}>
      <SafeAreaView style={homeStyles.safeArea}>
        <View style={homeStyles.header}>
          <View>
            <Text style={homeStyles.welcomeText}>Welcome to</Text>
            <Text style={homeStyles.brandName}>NOON</Text>
            <Text style={homeStyles.brandSub}>RESTAURANT</Text>
          </View>
          <TouchableOpacity 
            style={homeStyles.cartIcon}
            onPress={() => setShowCart(true)}
          >
            <Ionicons name="cart-outline" size={24} color={COLORS.primary} />
            {cartItems.length > 0 && (
              <View style={homeStyles.cartBadge}>
                <Text style={homeStyles.cartBadgeText}>{cartItems.length}</Text>
              </View>
            )}
          </TouchableOpacity>
        </View>

        <ScrollView showsVerticalScrollIndicator={false}>
          {/* Quick Options Row - Chote chote option buttons */}
          <View style={homeStyles.quickOptionsContainer}>
            <ScrollView horizontal showsHorizontalScrollIndicator={false}>
              {quickOptions.map((option) => (
                <TouchableOpacity
                  key={option.id}
                  style={homeStyles.quickOptionCard}
                  onPress={() => handleOptionPress(option)}
                >
                  <View style={homeStyles.quickOptionIcon}>
                    <Text style={homeStyles.quickOptionEmoji}>{option.icon}</Text>
                  </View>
                  <Text style={homeStyles.quickOptionName}>{option.name}</Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
          </View>

          {/* Categories Grid */}
          <View style={homeStyles.categoriesGrid}>
            {categories.map((cat) => (
              <TouchableOpacity
                key={cat.id}
                style={homeStyles.categoryCard}
                onPress={() => navigation.navigate(cat.screen)}
              >
                <Image source={{ uri: cat.image }} style={homeStyles.categoryImage} />
                <View style={homeStyles.categoryOverlay}>
                  <Text style={homeStyles.categoryIcon}>{cat.icon}</Text>
                  <Text style={homeStyles.categoryName}>{cat.name}</Text>
                </View>
              </TouchableOpacity>
            ))}
          </View>

          {/* Table Reservation */}
          <TouchableOpacity 
            style={homeStyles.reservationCard}
            onPress={() => setShowReservation(true)}
          >
            <Ionicons name="calendar" size={30} color={COLORS.primary} />
            <View style={homeStyles.reservationText}>
              <Text style={homeStyles.reservationTitle}>Book a Table</Text>
              <Text style={homeStyles.reservationDesc}>Reserve your table now</Text>
            </View>
            <Ionicons name="arrow-forward" size={24} color={COLORS.primary} />
          </TouchableOpacity>
        </ScrollView>

        {/* Cart Bar */}
        {cartItems.length > 0 && (
          <TouchableOpacity 
            style={homeStyles.cartBar}
            onPress={() => setShowCart(true)}
          >
            <View>
              <Text style={homeStyles.cartBarText}>{cartItems.length} items</Text>
              <Text style={homeStyles.cartBarTotal}>Rs. {grandTotal.toLocaleString()}</Text>
            </View>
            <View style={homeStyles.cartBarArrow}>
              <Ionicons name="arrow-forward" size={24} color={COLORS.black} />
            </View>
          </TouchableOpacity>
        )}

        {/* Modals */}
        <CartScreen
          visible={showCart}
          items={cartItems}
          onClose={() => setShowCart(false)}
          onCheckout={handleCheckout}
        />

        <PaymentScreen
          visible={showPayment}
          totalAmount={grandTotal.toLocaleString()}
          onClose={() => setShowPayment(false)}
          onPaymentComplete={handlePaymentComplete}
        />

        <ThankYouScreen
          visible={showThankYou}
          onClose={handleThankYouClose}
        />

        {/* Reservation Modal */}
        <Modal visible={showReservation} transparent>
          <View style={homeStyles.modalOverlay}>
            <View style={homeStyles.modalContent}>
              <Text style={homeStyles.modalTitle}>Book a Table</Text>
              
              <Text style={homeStyles.modalLabel}>Number of Guests</Text>
              <TextInput
                style={homeStyles.modalInput}
                placeholder="e.g., 2, 4, 6"
                placeholderTextColor={COLORS.gray}
                value={guests}
                onChangeText={setGuests}
                keyboardType="numeric"
              />
              
              <TouchableOpacity 
                style={homeStyles.modalButton}
                onPress={() => {
                  Alert.alert('Success', `Table booked for ${guests} guests`);
                  setShowReservation(false);
                }}
              >
                <Text style={homeStyles.modalButtonText}>Confirm Booking</Text>
              </TouchableOpacity>
              
              <TouchableOpacity onPress={() => setShowReservation(false)}>
                <Text style={homeStyles.modalClose}>Close</Text>
              </TouchableOpacity>
            </View>
          </View>
        </Modal>

        {/* Option Detail Modal */}
        {renderOptionDetail()}
      </SafeAreaView>
    </View>
  );
};

// ============ HOME STYLES ============
const homeStyles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  safeArea: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.primary,
  },
  welcomeText: {
    fontSize: 14,
    color: COLORS.textLight,
  },
  brandName: {
    fontSize: 36,
    fontWeight: 'bold',
    color: COLORS.primary,
    letterSpacing: 3,
  },
  brandSub: {
    fontSize: 16,
    color: COLORS.text,
    letterSpacing: 2,
  },
  cartIcon: {
    position: 'relative',
    padding: 8,
    backgroundColor: COLORS.card,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: COLORS.primary,
  },
  cartBadge: {
    position: 'absolute',
    top: -5,
    right: -5,
    backgroundColor: COLORS.primary,
    borderRadius: 10,
    minWidth: 20,
    height: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  cartBadgeText: {
    color: COLORS.black,
    fontSize: 10,
    fontWeight: 'bold',
  },
  
  // Quick Options Styles
  quickOptionsContainer: {
    paddingVertical: 15,
    paddingLeft: 15,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.border,
  },
  quickOptionCard: {
    alignItems: 'center',
    marginRight: 20,
    width: 70,
  },
  quickOptionIcon: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: COLORS.card,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 5,
    borderWidth: 1,
    borderColor: COLORS.primary,
  },
  quickOptionEmoji: {
    fontSize: 30,
  },
  quickOptionName: {
    fontSize: 11,
    color: COLORS.text,
    textAlign: 'center',
  },
  
  // Option Detail Modal
  optionDetailContent: {
    backgroundColor: COLORS.card,
    borderRadius: 30,
    padding: 20,
    width: '85%',
    maxHeight: '80%',
    borderWidth: 2,
    borderColor: COLORS.primary,
  },
  optionDetailHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 15,
    paddingBottom: 10,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.primary,
  },
  optionDetailTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: COLORS.primary,
  },
  optionDetailImage: {
    width: '100%',
    height: 150,
    borderRadius: 15,
    marginBottom: 15,
  },
  optionDetailDesc: {
    fontSize: 14,
    color: COLORS.textLight,
    marginBottom: 15,
    textAlign: 'center',
  },
  optionDetailItems: {
    backgroundColor: COLORS.black,
    borderRadius: 15,
    padding: 15,
    marginBottom: 15,
  },
  optionDetailItemsTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: COLORS.primary,
    marginBottom: 10,
  },
  optionDetailItem: {
    fontSize: 13,
    color: COLORS.text,
    marginBottom: 5,
  },
  optionDetailButton: {
    backgroundColor: COLORS.primary,
    padding: 12,
    borderRadius: 10,
    alignItems: 'center',
  },
  optionDetailButtonText: {
    color: COLORS.black,
    fontSize: 14,
    fontWeight: '600',
  },

  // Categories Grid
  categoriesGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    padding: 10,
  },
  categoryCard: {
    width: '45%',
    margin: '2.5%',
    height: 150,
    borderRadius: 15,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: COLORS.primary,
  },
  categoryImage: {
    width: '100%',
    height: '100%',
  },
  categoryOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0,0,0,0.7)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  categoryIcon: {
    fontSize: 40,
    marginBottom: 10,
  },
  categoryName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: COLORS.primary,
    textAlign: 'center',
  },

  // Reservation Card
  reservationCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.card,
    margin: 20,
    padding: 15,
    borderRadius: 15,
    borderWidth: 1,
    borderColor: COLORS.primary,
  },
  reservationText: {
    flex: 1,
    marginLeft: 15,
  },
  reservationTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: COLORS.primary,
    marginBottom: 4,
  },
  reservationDesc: {
    fontSize: 12,
    color: COLORS.textLight,
  },

  // Cart Bar
  cartBar: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: COLORS.card,
    paddingHorizontal: 20,
    paddingVertical: 15,
    borderTopWidth: 1,
    borderTopColor: COLORS.primary,
  },
  cartBarText: {
    color: COLORS.textLight,
    fontSize: 14,
  },
  cartBarTotal: {
    color: COLORS.primary,
    fontSize: 18,
    fontWeight: 'bold',
  },
  cartBarArrow: {
    backgroundColor: COLORS.primary,
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },

  // Modal Styles
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.9)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    backgroundColor: COLORS.card,
    padding: 20,
    borderRadius: 15,
    width: '80%',
    borderWidth: 1,
    borderColor: COLORS.primary,
  },
  modalTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: COLORS.primary,
    marginBottom: 20,
    textAlign: 'center',
  },
  modalLabel: {
    color: COLORS.textLight,
    fontSize: 14,
    marginBottom: 5,
  },
  modalInput: {
    backgroundColor: COLORS.black,
    borderRadius: 10,
    padding: 12,
    marginBottom: 15,
    color: COLORS.text,
    borderWidth: 1,
    borderColor: COLORS.primary,
  },
  modalButton: {
    backgroundColor: COLORS.primary,
    padding: 12,
    borderRadius: 10,
    marginBottom: 10,
  },
  modalButtonText: {
    color: COLORS.black,
    fontSize: 16,
    fontWeight: '600',
    textAlign: 'center',
  },
  modalClose: {
    color: COLORS.text,
    textAlign: 'center',
    padding: 10,
  },
});

// ============ MAIN APP ============
const App = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [currentScreen, setCurrentScreen] = useState('Home');
  const [cartItems, setCartItems] = useState([]);

  const menuData = {
    desi: [
      { id: 1, name: 'Chicken Karahi', price: '1899', weight: 'kg', description: 'Half kg - Spicy', image: IMAGES.chickenKarahi },
      { id: 2, name: 'Chicken Biryani', price: '1299', weight: 'kg', description: 'With raita', image: IMAGES.chickenBiryani },
      { id: 3, name: 'Mutton Handi', price: '2499', weight: 'kg', description: 'Full handi', image: IMAGES.muttonHandi },
      { id: 4, name: 'Daal Makhni', price: '899', weight: 'full', description: 'Creamy lentils', image: IMAGES.daalMakhni },
    ],
    fastfood: [
      { id: 5, name: 'Zinger Burger', price: '899', weight: 'single', description: 'Crispy chicken', image: IMAGES.zinger },
      { id: 6, name: 'Beef Burger', price: '999', weight: 'single', description: 'With cheese', image: IMAGES.zinger },
      { id: 7, name: 'Chicken Shawarma', price: '599', weight: 'single', description: 'Garlic sauce', image: IMAGES.zinger },
      { id: 8, name: 'French Fries', price: '399', weight: 'large', description: 'With ketchup', image: IMAGES.zinger },
    ],
    sweets: [
      { id: 9, name: 'Gulab Jamun', price: '399', weight: '4 pcs', description: 'Hot with syrup', image: IMAGES.daalMakhni },
      { id: 10, name: 'Kheer', price: '299', weight: 'bowl', description: 'Rice pudding', image: IMAGES.daalMakhni },
    ],
    drinks: [
      { id: 11, name: 'Karak Chai', price: '199', weight: 'cup', description: 'Hot tea', image: IMAGES.chai },
      { id: 12, name: 'Coffee', price: '349', weight: 'cup', description: 'Fresh brew', image: IMAGES.chai },
      { id: 13, name: 'Mango Lassi', price: '399', weight: 'glass', description: 'Sweet yogurt', image: IMAGES.chai },
      { id: 14, name: 'Cold Drink', price: '149', weight: '500ml', description: 'Chilled', image: IMAGES.chai },
    ],
  };

  const handleItemSelect = (item) => {
    if (cartItems.find(i => i.id === item.id)) {
      setCartItems(cartItems.filter(i => i.id !== item.id));
    } else {
      setCartItems([...cartItems, item]);
    }
  };

  const handleLogin = () => {
    setIsLoggedIn(true);
  };

  if (!isLoggedIn) {
    return <LoginScreen onLogin={handleLogin} />;
  }

  const renderScreen = () => {
    switch(currentScreen) {
      case 'Home':
        return <HomeScreen 
          navigation={{ 
            navigate: (screen) => setCurrentScreen(screen),
            goBack: () => setCurrentScreen('Home')
          }}
          cartItems={cartItems}
          setCartItems={setCartItems}
        />;
      case 'Desi':
        return <CategoryScreen 
          navigation={{ goBack: () => setCurrentScreen('Home') }}
          title="DESI FOOD"
          items={menuData.desi}
          onItemSelect={handleItemSelect}
          selectedItems={cartItems}
        />;
      case 'FastFood':
        return <CategoryScreen 
          navigation={{ goBack: () => setCurrentScreen('Home') }}
          title="FAST FOOD"
          items={menuData.fastfood}
          onItemSelect={handleItemSelect}
          selectedItems={cartItems}
        />;
      case 'Sweets':
        return <CategoryScreen 
          navigation={{ goBack: () => setCurrentScreen('Home') }}
          title="SWEETS"
          items={menuData.sweets}
          onItemSelect={handleItemSelect}
          selectedItems={cartItems}
        />;
      case 'Drinks':
        return <CategoryScreen 
          navigation={{ goBack: () => setCurrentScreen('Home') }}
          title="DRINKS & TEA"
          items={menuData.drinks}
          onItemSelect={handleItemSelect}
          selectedItems={cartItems}
        />;
      default:
        return <HomeScreen 
          navigation={{ navigate: (screen) => setCurrentScreen(screen) }}
          cartItems={cartItems}
          setCartItems={setCartItems}
        />;
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: COLORS.background }}>
      {renderScreen()}
    </View>
  );
};

export default App;

